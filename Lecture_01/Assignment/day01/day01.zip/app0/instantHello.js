let userName="Jack";
console.log("Hello "+userName);