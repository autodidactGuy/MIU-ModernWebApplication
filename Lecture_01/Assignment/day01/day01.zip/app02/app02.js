require ("./instantHello");

let goodbye=require ("./talk");

goodbye();