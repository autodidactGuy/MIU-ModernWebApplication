module.exports=function(){
    console.log("Good Bye!");
}