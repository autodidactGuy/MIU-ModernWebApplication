const answer="This is a good quesiton";

module.exports.ask=function(question){
    console.log(question);
    return answer;
}