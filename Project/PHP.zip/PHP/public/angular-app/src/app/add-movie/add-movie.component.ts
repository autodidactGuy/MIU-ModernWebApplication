import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { MoviesDataService } from '../movies-data.service';
import { Movie } from '../movies/movies.component';
@Component({
  selector: 'app-add-movie',
  templateUrl: './add-movie.component.html',
  styleUrls: ['./add-movie.component.css']
})
export class AddMovieComponent implements OnInit {

  addMovieForm!:FormGroup;
  movie!:Movie;
  hasSuccess!:boolean;
  successMessage!:string;
  constructor(private _router:Router,private _formBuilder:FormBuilder,private _moviesService:MoviesDataService) {
    this.addMovieForm=this._formBuilder.group({
      title: "Martian",
      year: 2011,
      rating: 0.0,
      banner: "https://image.tmdb.org/t/p/w300/pFlaoHTZeyNkG83vxsAJiGzfSsa.jpg",
      director: "Hassan Raza",
      plot: "Summary of movie"
    });
    this.hasSuccess=false;
    this.successMessage="";
  }

  ngOnInit(): void {
  }

  navigateToMovies(){
    this._router.navigate(["/movies"]);
  }

  onSubmit():void{
    console.log(this.addMovieForm.value);
    this.movie=this.addMovieForm.value;
    this._moviesService.addMovie(this.movie).subscribe(value => {
      this.hasSuccess=true;
      this.successMessage="Movie Added";
      setTimeout(this.navigateToMovies,2000);
    });
  }

}
