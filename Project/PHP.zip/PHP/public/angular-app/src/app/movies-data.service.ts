import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Movie } from './movies/movies.component';
import {JwtHelperService} from '@auth0/angular-jwt';
import { AuthenticationService } from './authentication.service';
import { HttpHeaders } from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class MoviesDataService {

  private _baseUrl:string="http://localhost:3000/api";

  _auth!:AuthenticationService;
  constructor(private _http:HttpClient) { 
    this._auth=new AuthenticationService(new JwtHelperService());
  }

  public getMovies(offset:Number,count:Number): Observable<Movie[]>{
    const url:string=this._baseUrl+"/movies?offset="+offset+"&count="+count;
    return this._http.get(url) as Observable<Movie[]>;
  }

  public searchMovies(search:string,offset:Number,count:Number): Observable<Movie[]> {
    const url: string= this._baseUrl + "/movies?search="+search+"&offset="+offset+"&count="+count;
    return this._http.get<Movie[]>(url);
  }

  public getMovie(movieId:string): Observable<Movie>{
    const url:string=this._baseUrl+"/movies/"+movieId;
    return this._http.get(url) as Observable<Movie>;
  }

  public addMovie(movie: Movie):Observable<Movie>{
    
    const url:string=this._baseUrl+"/movies";
    const header = new HttpHeaders({
      'Authorization': 'Bearer ' + this._auth.token
    });
    return this._http.post<Movie>(url,movie,{
      headers: header
    });
  }

  public getMoviesCount():Observable<any>{
    const url:string=this._baseUrl+"/movies/count";
    return this._http.get(url) as Observable<any>;
  }
}
