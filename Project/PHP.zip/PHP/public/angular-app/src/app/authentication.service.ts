import { Injectable } from '@angular/core';
import {JwtHelperService} from '@auth0/angular-jwt';
@Injectable({
  providedIn: 'root'
})
export class Authentication{
  #success:boolean=false;
  get success(){return this.#success;}
  set success(success:boolean){ this.#success=success; }

  #token:string="";
  get token(){return this.#token;}
  set token(token:string){ this.#token=token; }
}
export class AuthenticationService {

  #isLoggedIn:boolean=false;
  get isLoggedIn(){
    if(this.token){
      return true;
    }
    return false;
  }

  #token:string="";
  get token():string{return localStorage.getItem("token")!;}
  set token(token:string){ localStorage.setItem("token",token) }

  removeToken(){
    localStorage.clear();
  }

  #username:string="";
  get username(){
    if(this.token){
      return this._jwtHelperService.decodeToken(this.token).username;
    }else{
      return "";
    }
  }

  constructor(private _jwtHelperService:JwtHelperService) { }
}
