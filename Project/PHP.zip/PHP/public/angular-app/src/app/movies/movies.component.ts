import { Component, OnInit } from '@angular/core';
import { MoviesDataService } from '../movies-data.service';
import { ActivatedRoute, Router } from '@angular/router';

export class Review{
  _id!:string;
  username!:string;
  rating!: Number;
  description!: String;
}

export class Movie{
  #_id!:string;
  #title!:string;
  #banner!:string;
  #rating!:Number;
  #year!:Number;
  #director!:string;
  #writers!:[string];
  #cast!:[string];
  #reviews!:[Review];
  #genre!:[string];
  #plot!:string;

  set _id(_id:string){ this.#_id=_id;}
  get _id(){return this.#_id; }
  set title(title:string){ this.#title=title;}
  get title(){return this.#title; }
  set banner(banner:string){ this.#banner=banner;}
  get banner(){return this.#banner; }
  set rating(rating:Number){ this.#rating=rating;}
  get rating(){return this.#rating; }
  set year(year:Number){ this.#year=year;}
  get year(){return this.#year; }
  set director(director:string){ this.#director=director;}
  get director(){return this.#director; }

  set writers(writers:[string]){this.#writers=writers}
  get writers(){ return this.#writers;}
  
  set cast(cast:[string]){this.#cast=cast}
  get cast(){ return this.#cast;}
  
  set reviews(reviews:[Review]){this.#reviews=reviews}
  get reviews(){ return this.#reviews;}
  
  set genre(genre:[string]){this.#genre=genre}
  get genre(){ return this.#genre;}
  
  set plot(plot:string){this.#plot=plot}
  get plot(){ return this.#plot;}

}


@Component({
  selector: 'app-movies',
  templateUrl: './movies.component.html',
  styleUrls: ['./movies.component.css']
})
export class MoviesComponent implements OnInit {

  movies:Movie[]=[];
  moviesCount!:Number;
  pages:Number[]=[];

  searchInput!:string;
  constructor(private _moviesService:MoviesDataService,private _router:Router,private _activatedRouter:ActivatedRoute) {
    this._router.routeReuseStrategy.shouldReuseRoute = () => {
      return false;
    };
  }

  ngOnInit(): void {

    let offset=this._activatedRouter.snapshot.queryParams["offset"];
    let count=this._activatedRouter.snapshot.queryParams["count"];
    if(!offset){
      offset=0;
    }
    if(!count){
      count=5;
    }

    this._moviesService.getMoviesCount().subscribe(value=>{
      this.moviesCount=value.count;
      this._renderPages();
    })
    
    this._moviesService.getMovies(offset,count).subscribe(value=>{
      this.movies=value;
    })
  }

  onSearch():void{
    let count:number=5;
    let offset:Number=0;
    console.log(this.searchInput);
    
    this._moviesService.searchMovies(this.searchInput,offset,count).subscribe({
      next: (movies)=> this.movies=movies,
      error: (error)=>{this.movies= []; console.log(error);
      },
    });
  }

  _renderPages(){
    let noOfPages:Number=Math.ceil(Number(this.moviesCount)/5);
    console.log(noOfPages);
    this.pages=new Array<Number>(noOfPages);

  }

  onPage(offset:any){
    this._router.navigate(["movies"],{ queryParams: {offset: offset}});
  }

}
