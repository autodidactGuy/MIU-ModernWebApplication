import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { FormGroup } from '@angular/forms';
import { Router, TitleStrategy } from '@angular/router';
import {JwtHelperService} from '@auth0/angular-jwt';
import { Authentication, AuthenticationService } from '../authentication.service';
import { UserDataService } from '../user-data.service';
export class Credentials{
  #username!:string;
  #password!:string;
  #name!:string;

  /*constructor(username:string,password:string){
    this.username=username;
    this.password=password;
  }*/
  set username(username:string){
    this.#username=username;
  }
  set password(password:string){
    this.#password=password;
  }

  set name(name:string){
    this.#name=name;
  }

  get username():string{
    return this.#username;
  }
  get password():string{
    return this.#password;
  }

  get name():string{
    return this.#name;
  }

  toJSON(){
    return {
      name: this.name,
      username: this.username,
      password: this.password
    }
  }

  fillFromForm(form:FormGroup){
    this.#name=form.value.name;
    this.#username=form.value.username;
    this.#password=form.value.password;
  }

  fillFromFormNgForm(form:NgForm){
    this.#username=form.value.username;
    this.#password=form.value.password;
  }
}
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  //user:Credentials=new Credentials("username","password");
  successMessage:string="";
  hasSuccess:boolean=false;
  errorMessage:string="";
  hasError:boolean=false;


  
  get isLoggedIn():boolean {return this._auth.isLoggedIn;}

  _auth!:AuthenticationService;

  username!:string;

  @ViewChild("loginForm")
  loginForm!:NgForm;

  constructor(private _userServices:UserDataService,private _router:Router) {

  }

  ngOnInit(): void {
    this._auth=new AuthenticationService(new JwtHelperService());
    this.username=this._auth.username;
    setTimeout(()=>{
      //console.log("Hello there!",this.user.toJSON());
      //this.loginForm.setValue(this.user.toJSON());
    },0); 
  }

  onLogin(){
    console.log("Login clicked");
    console.log(this.loginForm.value);

    //let user:Credentials=new Credentials(this.loginForm.value.username,this.loginForm.value.password);
    const user:Credentials=new Credentials();
    user.fillFromFormNgForm(this.loginForm);

    this._userServices.login(user).subscribe({
      next: (result)=>{
        this.hasSuccess=true;
        this.successMessage="Login Success!";
        this.hasError=false;
        this._auth.token=result.token;
        this.username=this._auth.username;
        console.log("login result",result);
        this.onClear();
      },
      error: ()=>{
        this.hasError=true;
        this.errorMessage="Login Failed!";
        this.hasSuccess=false;
      },
      complete: ()=>{
        if(this.hasSuccess){
          this.hideMessagesWithDelay();
        }

      }
    });
  }

  hideMessagesWithDelay(callback=()=>{}){
    setTimeout(() => {
      this.hasSuccess=false;
      this.hasError=false;
      callback();
    }, 2000);
  }

  onClear(){
    this.loginForm.setValue({username:"",password:""});
  }

  logout(){
    console.log("logging out");
    
    this.hasSuccess=true;
    this.successMessage="Logging out...";
    this.hideMessagesWithDelay(()=>{
      this._auth.removeToken();
    });
  }
}
