import { Component, OnInit } from '@angular/core';
import { FormGroup,FormControl, FormBuilder } from '@angular/forms';
import { UserDataService } from '../user-data.service';
import { Credentials } from '../login/login.component';
import { Router } from '@angular/router';
@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  successMessage:string="";
  hasSuccess:boolean=false;
  errorMessage:string="";
  hasError:boolean=false;
  registrationForm!:FormGroup;
  constructor(private _formBuilder: FormBuilder, private _userServices:UserDataService,private _router:Router) {
    this.registrationForm=this._formBuilder.group({
      name: "",
      username: "",
      password: "",
      passwordRepeat: ""
    })
   }

  ngOnInit(): void {
  }


  onSubmit():void{
    console.log("form",this.registrationForm.value);
    const user:Credentials=new Credentials();
    user.fillFromForm(this.registrationForm);

    this._userServices.addUser(user).subscribe({
      next: ()=>{
        this.hasSuccess=true;
        this.successMessage="Registration Success!";
        this.hasError=false;
      },
      error: ()=>{
        this.hasError=true;
        this.errorMessage="Registration Failed!";
        this.hasSuccess=false;
      },
      complete: ()=>{
        if(this.hasSuccess){
          setTimeout(() => {
            this._router.navigate([""]);
          }, 2000);
        }

      }
    });
    
  }
}
