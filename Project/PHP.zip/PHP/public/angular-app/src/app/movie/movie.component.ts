import { Component, OnInit } from '@angular/core';
import { MoviesDataService } from '../movies-data.service';
import { Movie } from '../movies/movies.component';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-movie',
  templateUrl: './movie.component.html',
  styleUrls: ['./movie.component.css']
})
export class MovieComponent implements OnInit {

  movie!:Movie;
  constructor(private _moviesService:MoviesDataService,private _router:ActivatedRoute) { }

  ngOnInit(): void {
    let movieId=this._router.snapshot.params["movieId"];
    this._moviesService.getMovie(movieId).subscribe(value=>{
      this.movie=value;
    })
  }

}
