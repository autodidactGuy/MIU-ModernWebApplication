import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Credentials } from './login/login.component'; 
import { Authentication } from './authentication.service';

@Injectable({
  providedIn: 'root'
})
export class UserDataService {

  //private _baseUrl:string="https://meowfacts.herokuapp.com/";
  private _baseUrl:string="http://localhost:3000/api";
  //Lecture_03 app01
  constructor(private _http:HttpClient) {

  }

  

  public addUser(user:Credentials): Observable<Credentials>{
    const url:string=this._baseUrl+"/users";
    return this._http.post(url,user) as Observable<Credentials>;
  }

  public login(user:Credentials): Observable<Authentication>{
    const url:string=this._baseUrl+"/users/login";
    return this._http.post(url,user) as Observable<Authentication>;
  }
 
}
