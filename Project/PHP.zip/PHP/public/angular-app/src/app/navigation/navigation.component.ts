import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthenticationService } from '../authentication.service';
import {JwtHelperService} from '@auth0/angular-jwt';

@Component({
  selector: 'app-navigation',
  templateUrl: './navigation.component.html',
  styleUrls: ['./navigation.component.css']
})
export class NavigationComponent implements OnInit {

  get isLoggedIn():boolean {return this._auth.isLoggedIn;}
  _auth!:AuthenticationService;
  constructor(private _router:Router) { 
    this._router.routeReuseStrategy.shouldReuseRoute = () => {
      return false;
    };
  }

  ngOnInit(): void {
    this._auth=new AuthenticationService(new JwtHelperService());
  }

  navigate(route:string):void{
    this._router.navigate([route]);
    //this._router.navigateByUrl(route);
  }

  

}
