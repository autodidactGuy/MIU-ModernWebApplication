const express=require("express");
const reviewsController=require("../controllers/reviews.controller");
const authController=require("../controllers/authentication.controller");
const router=express.Router({mergeParams: true});

router.route("/")
    .get(reviewsController.getAll)
    .post(authController.authenticate,reviewsController.insertOne);

router.route("/:reviewId")
    .get(reviewsController.getOne)
    .delete(authController.authenticate,reviewsController.insertOne)
    .patch(authController.authenticate,reviewsController.updateOne)
    .post(authController.authenticate,reviewsController.insertOne)

module.exports=router;