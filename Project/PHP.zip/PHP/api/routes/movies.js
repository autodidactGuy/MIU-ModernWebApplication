const express=require("express");
const moviesController=require("../controllers/movies.controller");
const authController=require("../controllers/authentication.controller");
const reviewsRoutes=require("./reviews");
const router=express.Router({mergeParams: true});

router.route("/")
    .get(moviesController.getAll)
    .post(authController.authenticate,moviesController.insertOne);

router.route("/count")
    .get(moviesController.moviesCount);

router.route("/:movieId")
    .get(moviesController.getOne)
    .put(authController.authenticate,moviesController.updateOne)
    .patch(authController.authenticate,moviesController.updateOnePartial)
    .delete(authController.authenticate,moviesController.deleteOne);

router.use("/:movieId/reviews",reviewsRoutes);

module.exports=router;