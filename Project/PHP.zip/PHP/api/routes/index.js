const express=require("express");
const moviesRoutes=require("./movies");
const userRoutes=require("./users");
const router=express.Router();

router.use('/movies',moviesRoutes);
router.use('/users',userRoutes);

module.exports=router;