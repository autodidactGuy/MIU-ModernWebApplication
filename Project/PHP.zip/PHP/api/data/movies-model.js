const mongoose=require("mongoose");

const reviewsSchema=new mongoose.Schema({
    username: {
        type: String,
        required: true
    },
    rating:{
        type: Number,
        default: 0.0,
        min: 0.0,
        max: 10.0
    },
    description:{
        type: String,
        required: true
    },
    createdAt:{
        type: Date,
        default: Date.now
    }
});

const movieSchema=mongoose.Schema({
    title: {
        type: String,
        required: true
    },
    banner:{
        type: String,
        required: true
    },
    rating: {
        type: Number,
        default: 0.0,
        min: 0.0,
        max: 10.0
    },
    year: {
        type: Number,
        required: true
    },
    director: {
        type: String,
        required: true
    },
    cast: {
        type: [String],
        required: true
    },
    writers: {
        type: [String],
        required: true
    },
    genre: {
        type: [String],
        required: true
    },
    plot: {
        type: String
    },
    reviews: [reviewsSchema]
});

mongoose.model(process.env.MOVIE_MODEL,movieSchema,process.env.MOVIE_COLLECTION);