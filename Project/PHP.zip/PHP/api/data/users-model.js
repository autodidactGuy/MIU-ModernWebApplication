const mongoose=require("mongoose");

const userSchema=new mongoose.Schema({
    name: String,
    username: {
        type: String,
        required: true,
        unique: true
    },
    password: {
        type: String,
        required: true
    },
    userType:{
        type: String,
        default: process.env.DEFAULT_USER_TYPE
    }
});

mongoose.model(process.env.USER_MODEL,userSchema,process.env.USER_COLLECTION);