const mongoose=require("mongoose");

const Movie=mongoose.model(process.env.MOVIE_MODEL);

_debugLog=function(message){
    if(JSON.parse(process.env.DEBUG_FLAG)){
        console.log(message);
    }
}

_createDefaultResponse=function(status=200,message=""){
    const response={
        status: status,
        message:message
    };
    return response;
}

_validateAndPrepareData=function(data,response,type=process.env.RESPONSE_TYPE_ARRAY,status=process.env.OK_STATUS_CODE){
    
    return new Promise((resolve,reject)=>{
        if(!data || data.length==0){
            response.status=parseInt(process.env.ERROR_NOT_FOUND_CODE);
            response.message={message: process.env.NO_MOVIES_FOUND_MESSAGE};
            if(type==process.env.RESPONSE_TYPE_OBJECT){
                response.message={message: process.env.SPECIFIC_MOVIE_NOT_FOUND_MESSAGE};
            }
            reject();
        }else{
            response.status=parseInt(status);
            response.message=data;
            resolve(data);
        }
    })
}

_prepareCount=function(count,response){
    return new Promise((resolve,reject)=>{
        response.status=process.env.OK_STATUS_CODE;
        response.message={count: count};
        resolve();
    })
}

_handleError=function(err,response){
    if(response.status==process.env.OK_STATUS_CODE || response.status==process.env.OK_POST_CODE){
        response.status=parseInt(process.env.INTERNAL_SERVER_ERROR_CODE);
        response.message={message: err};
    }
}

_sendResponse=function(res,response){
    res.status(response.status).json(response.message);
}

_findMovie=function(query,offset,count,res){
    const response=_createDefaultResponse();
    Movie.find(query).skip(offset).limit(count)
            .then((movies)=> _validateAndPrepareData(movies,response))
            .catch((error) => _handleError(error,response))
            .finally(() => _sendResponse(res,response));
}

module.exports.moviesCount=function(req,res){
    const response=_createDefaultResponse();
    Movie.find().count()
            .then((moviesCount)=>_prepareCount(moviesCount,response))
            .catch((error) => _handleError(error,response))
            .finally(() => _sendResponse(res,response));
}

module.exports.getAll=function(req,res){

    let offset=parseInt(process.env.DEFAULT_OFFSET);
    let count=parseInt(process.env.DEFAULT_COUNT);
    let maxCount=parseInt(process.env.DEFAULT_MAX_COUNT);
    let search="";
    if(req.query && req.query.offset){
        offset=parseInt(req.query.offset);
    }
    if(req.query && req.query.count){
        count=parseInt(req.query.count);
    }

    if(isNaN(offset) || isNaN(count)){
        res.status(parseInt(process.env.ERROR_BAD_REQUEST_CODE)).json({message: process.env.OFFSET_COUNT_MESSAGE});
        return;
    }

    if(count>maxCount){
        res.status(parseInt(process.env.ERROR_BAD_REQUEST_CODE)).json({message: process.env.MAX_COUNT_MESSAGE+maxCount});
        return;
    }

    let query={};

    if(req.query && req.query.search){
        query={title: {$regex: ".*"+req.query.search+".*"}};
    }

    _findMovie(query,offset,count,res);

}

module.exports.getOne=function(req,res){

    const movieId=req.params.movieId;
    const validMovieId=mongoose.isValidObjectId(movieId);
    
    if(validMovieId){
        const response=_createDefaultResponse();
        Movie.findById(movieId)
                .then((movie)=> _validateAndPrepareData(movie,response,process.env.RESPONSE_TYPE_OBJECT))
                .catch((error) => _handleError(error,response))
                .finally(() => _sendResponse(res,response));
    }
    else{
        res.status(process.env.ERROR_POST_CODE).json({message: process.env.INVALID_MOVIE_ID_MESSAGE});
    }
}

module.exports.insertOne=function(req,res){

    let newMovie={title,year,director,banner,imdbRating}=req.body;
    const response=_createDefaultResponse();
    Movie.create(newMovie)
            .then((newMmovie)=> _validateAndPrepareData(newMmovie,response,process.env.RESPONSE_TYPE_OBJECT,process.env.OK_POST_CODE))
            .catch((error) => _handleError(error,response))
            .finally(() => _sendResponse(res,response));
}

module.exports.deleteOne= function (req, res) {
    const movieId = req.params.movieId;
    const response=_createDefaultResponse();
    Movie.findByIdAndRemove(movieId)
            .then((deletedMovie)=> _validateAndPrepareData(deletedMovie,response,process.env.RESPONSE_TYPE_OBJECT))
            .catch((error) => _handleError(error,response))
            .finally(() => _sendResponse(res,response));
}

_saveMovie=function(movie){
    return movie.save();
}

_updateFull=function(req,res,movie){
    
    movie.title=req.body.title;
    movie.year=req.body.year;
    movie.director=req.body.director;
    movie.banner=req.body.banner;
    movie.rating=req.body.rating;
    movie.cast=req.body.cast;
    movie.genre=req.body.genre;
    movie.writers=req.body.writers;
    movie.plot=req.body.plot;
    _saveMovie(movie);
}

_updatePartial=function(req,res,movie){
    let {title,year,director,banner,rating,cast,genre,writers,plot}=req.body;

    if(title){
        movie.title=req.body.title;
    }
    if(year){
        movie.year=req.body.year;
    }
    if(director){
        movie.director=req.body.director;
    }
    if(banner){
        movie.banner=req.body.banner;
    }
    if(rating){
        movie.rating=req.body.rating;
    }
    if(cast){
        movie.cast=req.body.cast;
    }
    if(writers){
        movie.writers=req.body.writers;
    }
    if(genre){
        movie.genre=req.body.genre;
    }
    if(plot){
        movie.plot=req.body.plot;
    }
    _saveMovie(movie);
}

_updateMovie=function(req,res,updateFunction){
    const movieId = req.params.movieId;
    const response=_createDefaultResponse();
    Movie.findById(movieId)
            .then((movie)=> _validateAndPrepareData(movie,response,process.env.RESPONSE_TYPE_OBJECT))
            .then((movie)=> updateFunction(req,res,movie))
            .catch((error) => _handleError(error,response))
            .finally(() => _sendResponse(res,response));  
}

module.exports.updateOne= function (req, res) {
    _updateMovie(req,res,_updateFull);
}

module.exports.updateOnePartial= function (req, res) {
    _updateMovie(req,res,_updatePartial);
}