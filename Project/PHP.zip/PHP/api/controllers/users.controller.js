const mongoose=require("mongoose");
const bcrypt=require("bcrypt");
const jwt=require("jsonwebtoken");

require("./../data/users-model");

const User=mongoose.model("User");

_hashPassword=function(password,salt){
    return bcrypt.hash(password,salt);
}

_addHashedPasswordtoUser=function(newUser,hashedPassword){
    return new Promise((resolve,reject)=>{
        if(newUser){
            newUser.password=hashedPassword;
            resolve();
        }else{
            reject();
        }
    })
}

_createUser=function(newUser){
    return User.create(newUser);
}

_prepareSuccessResponse=function(user,response){
    response.status=parseInt(process.env.OK_POST_CODE);
    response.message=user
}

register=function(req,res){

    const newUser={
        name,username,password
    }=req.body;
    const response=_createDefaultResponse();
    bcrypt.genSalt(10)
            .then((salt)=> _hashPassword(newUser.password,salt))
            .then((hashedPassword)=> _addHashedPasswordtoUser(newUser,hashedPassword))
            .then(()=> _createUser(newUser))
            .then((user)=> _prepareSuccessResponse(user,response))
            .catch((error) => _handleError(error,response))
            .finally(() => _sendResponse(res,response));
}

_debugLog=function(message){
    if(JSON.parse(process.env.DEBUG_FLAG)){
        console.log(message);
    }
}

_createDefaultResponse=function(status=200,message=""){
    const response={
        status: status,
        message:message
    };
    return response;
}


login=function(req,res){
    _debugLog("Login called");
    const response=_createDefaultResponse();
    const {username,password}=req.body;
    User.findOne({username:username})
            .then((user) => _checkIfUserExists(user,response))
            .then((user) => _checkPassword(password,user,response))
            .then((user) =>_generateToken(user,response))
            .catch((error) => _handleError(error,response))
            .finally(() => _sendResponse(res,response));
}

_checkIfUserExists=function(user,response){
    return new Promise((resolve,reject)=>{
        if(!user){
            response.status=401;
            response.message="Unauthorized";
            reject();
        }else{
            resolve(user);
        }
    })
}

_checkPassword=function(password,user,response){
    return new Promise((resolve,reject)=> {
        bcrypt.compare(password,user.password)
                .then((passwordMatch)=>{
                    if(passwordMatch){
                        resolve(user);
                    }else{
                        _debugLog("INCORRECT PASSWORD");
                        response.status=401;
                        response.message="Unauthorized";
                        reject();
                    }
                })
                .catch((error)=>{
                    _debugLog("bcrypt compare error"+error);
                    response.status=500;
                    response.message="error";
                    reject();
                })
    })
}

_generateToken=function(user,response){
    _debugLog("Login success");
    response.status=200;
    const token=jwt.sign({username: user.username},process.env.JWT_PASSWORD,{expiresIn: 3600});
    response.message={success: true,token: token};
}
_handleError=function(err,response){
    if(response.status==process.env.OK_STATUS_CODE || response.status==process.env.OK_POST_CODE){
        response.status=parseInt(process.env.INTERNAL_SERVER_ERROR_CODE);
        response.message={message: err};
    }
}

_sendResponse=function(res,response){
    res.status(response.status).json(response.message);
}

module.exports={
    insertOne: register,
    login: login
}