const mongoose=require("mongoose");

const Movie=mongoose.model(process.env.MOVIE_MODEL);

_debugLog=function(message){
    if(JSON.parse(process.env.DEBUG_FLAG)){
        console.log(message);
    }
}

_createDefaultResponse=function(status=200,message=""){
    const response={
        status: status,
        message:message
    };
    return response;
}

_validateAndPrepareReviewData=function(data,response,type=process.env.RESPONSE_TYPE_ARRAY,singleId="",status=process.env.OK_STATUS_CODE){
    return new Promise((resolve,reject)=>{
        if(!data || data.length==0){
            response.status=parseInt(process.env.ERROR_NOT_FOUND_CODE);
            response.message={message: process.env.NO_REVIEW_FOUND_MESSAGE};
            if(type==process.env.RESPONSE_TYPE_OBJECT){
                response.message={message: process.env.SPECIFIC_REVIEW_NOT_FOUND_MESSAGE};
            }
            reject();
        }else{
            response.status=parseInt(status);
            if(type==process.env.RESPONSE_TYPE_OBJECT){
                let reviews=data.reviews.id(singleId);
                response.message=reviews;
            }else{
                response.message=data.reviews;
            }
            resolve(data);
        }
    })
}

_prepareCount=function(count,response){
    return new Promise((resolve,reject)=>{
        response.status=process.env.OK_STATUS_CODE;
        response.message={count: count};
        resolve();
    })
}

_handleError=function(err,response){
    if(response.status==process.env.OK_STATUS_CODE || response.status==process.env.OK_POST_CODE){
        response.status=parseInt(process.env.INTERNAL_SERVER_ERROR_CODE);
        response.message={message: err};
    }
}

module.exports.getAll=function(req,res){
    const movieId= req.params.movieId;
    let offset=parseInt(process.env.DEFAULT_OFFSET);
    let count=parseInt(process.env.DEFAULT_COUNT);
    let maxCount=parseInt(process.env.DEFAULT_MAX_COUNT);
    
    if(req.query && req.query.offset){
        offset=parseInt(req.query.offset);
    }
    if(req.query && req.query.count){
        count=parseInt(req.query.count);
    }

    if(isNaN(offset) || isNaN(count)){
        res.status(parseInt(process.env.ERROR_BAD_REQUEST_CODE)).json({message: process.env.OFFSET_COUNT_MESSAGE});
        return;
    }

    if(count>maxCount){
        res.status(parseInt(process.env.ERROR_BAD_REQUEST_CODE)).json({message: process.env.MAX_COUNT_MESSAGE+maxCount});
        return;
    }
    const response=_createDefaultResponse();
    Movie.findById(movieId).select(process.env.REVIEWS_SUB_DOC).skip(offset).limit(count)
            .then((movie)=> _validateAndPrepareReviewData(movie,response))
            .catch((error) => _handleError(error,response))
            .finally(() => _sendResponse(res,response));
}

module.exports.getOne=function(req,res){
    const movieId=req.params.movieId;
    const reviewId=req.params.reviewId;
    const validMovieId=mongoose.isValidObjectId(movieId);
    const validreviewId=mongoose.isValidObjectId(reviewId);
    if(validMovieId && validreviewId){
        const response=_createDefaultResponse();
        Movie.findById(movieId).select(process.env.REVIEWS_SUB_DOC)
                .then((movie)=> _validateAndPrepareReviewData(movie,response,process.env.RESPONSE_TYPE_OBJECT,reviewId))
                .catch((error) => _handleError(error,response))
                .finally(() => _sendResponse(res,response));
    }
    else{
        res.status(process.env.ERROR_POST_CODE).json({message: process.env.INVALID_MOVIE_OR_REVIEW_ID_MESSAGE});
    }
}

const _addreviews=function(req,movie){
    let newreviews ={username,rating,description}=req.body;
    movie.reviews.push(newreviews);
    return movie.save();
}

_prepareSuccessResponse=function(movie,response){
    response.status=parseInt(process.env.OK_POST_CODE);
    response.message=movie
}

module.exports.insertOne= function(req, res) {
    const movieId= req.params.movieId;
    console.log(movieId);
    const response=_createDefaultResponse();
    Movie.findById(movieId).select(process.env.REVIEWS_SUB_DOC)
            .then((movie)=> _validateAndPrepareReviewData(movie,response,process.env.RESPONSE_TYPE_OBJECT,"",process.env.OK_POST_CODE))
            .then((movie)=> _addreviews(req,movie))
            .then((movie)=> _prepareSuccessResponse(movie,response))
            .catch((error) => _handleError(error,response))
            .finally(() => _sendResponse(res,response));
}

_removeReview=function(movie,reviewId){
    movie.reviews=movie.reviews.filter(function(reviews){
        if(reviews._id!=reviewId){
            return reviews;
        }
    });
    return movie.save();
}

module.exports.deleteOne= function (req, res) {
    const movieId = req.params.movieId;
    const reviewId = req.params.reviewId;
    const validMovieId=mongoose.isValidObjectId(movieId);
    const validReviewID=mongoose.isValidObjectId(reviewId);
    if(validMovieId && validReviewID){
        const response=_createDefaultResponse();
        Movie.findById(movieId).select(process.env.REVIEWS_SUB_DOC)
                .then((movie)=> _validateAndPrepareReviewData(movie,response))
                .then((movie)=> _removeReview(movie,reviewId))
                .then((movie)=> _prepareSuccessResponse(movie,response))
                .catch((error) => _handleError(error,response))
                .finally(() => _sendResponse(res,response));
    }
    else{
        res.status(process.env.ERROR_POST_CODE).json({message: process.env.INVALID_MOVIE_OR_REVIEW_ID_MESSAGE});
    }
}

_updateReview=function(movie,req,reviewId){
    let {username,rating,description}=req.body;
    movie.reviews=movie.reviews.map(function(reviews){
        if(reviews._id==reviewId){
            if(username){
                reviews.username=username;
            }
            if(rating){
                reviews.rating=rating;
            }
            if(description){
                reviews.description=description;
            }
        }
        return reviews;
    });
    return movie.save();
}

module.exports.updateOne=function (req, res) {
    const movieId = req.params.movieId;
    const reviewId=req.params.reviewId;
    const response=_createDefaultResponse();
    Movie.findById(movieId).select(process.env.REVIEWS_SUB_DOC)
            .then((movie)=> _validateAndPrepareReviewData(movie,response))
            .then((movie)=> _updateReview(movie,req,reviewId))
            .then((movie)=> _prepareSuccessResponse(movie,response))
            .catch((error) => _handleError(error,response))
            .finally(() => _sendResponse(res,response));
}